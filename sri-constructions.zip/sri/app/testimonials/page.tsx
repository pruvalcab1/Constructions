import { CTASection, PageHero, Section, Testimonials } from "@/components/ui";
import { meta } from "@/lib/seo";
export const metadata = meta("Testimonials", "Client feedback on working with Sri Constructions.", "/testimonials");
export default function T() { return (<><PageHero title="Client Testimonials" text="Sample content. Replace with real testimonials in lib/site.ts." crumbs={[["Testimonials", "/testimonials"]]} /><Section><Testimonials /></Section><CTASection /></>); }
