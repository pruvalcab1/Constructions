import Link from "next/link";
import { PageHero, Section } from "@/components/ui";
import { nav, posts, projects, services } from "@/lib/site";
import { meta } from "@/lib/seo";
export const metadata = meta("Sitemap", "All pages on the Sri Constructions website.", "/sitemap-page");
export default function S() {
  const g: [string, [string, string][]][] = [["Main", nav.map(([l, h]) => [l, h])], ["Services", services.map((s) => [s.title, `/services/${s.slug}`])], ["Projects", projects.map((p) => [p.name, `/projects/${p.slug}`])], ["Blog", posts.map((p) => [p.title, `/blog/${p.slug}`])]];
  return (<><PageHero title="Sitemap" crumbs={[["Sitemap", "/sitemap-page"]]} /><Section><div className="grid gap-10 md:grid-cols-4">{g.map(([t, l]) => <div key={t}><h2 className="font-display text-xl text-navy">{t}</h2><ul className="mt-3 space-y-2">{l.map(([n, h]) => <li key={h}><Link href={h} className="hover:text-gold">{n}</Link></li>)}</ul></div>)}</div></Section></>);
}
