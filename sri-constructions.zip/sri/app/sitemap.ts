import type { MetadataRoute } from "next";
import { posts, projects, services, site } from "@/lib/site";
export default function sitemap(): MetadataRoute.Sitemap {
  const p = ["", "/about", "/services", "/projects", "/why-us", "/testimonials", "/faq", "/blog", "/contact", "/privacy", "/terms", ...services.map((s) => `/services/${s.slug}`), ...projects.map((x) => `/projects/${x.slug}`), ...posts.map((x) => `/blog/${x.slug}`)];
  return p.map((u) => ({ url: site.url + u, lastModified: new Date() }));
}
