import { PageHero, Section } from "@/components/ui";
import { meta } from "@/lib/seo";
export const metadata = meta("Privacy Policy", "Privacy Policy for the Sri Constructions website.", "/privacy");
export default function Page() { return (<><PageHero title="Privacy Policy" crumbs={[["Privacy Policy", "/privacy"]]} /><Section><div className="mx-auto max-w-2xl space-y-5 text-ink/75"><p>[ADD Privacy Policy. Have this reviewed by a legal professional before launch.]</p><p>Enquiries submitted through this website are used only to respond to your request.</p></div></Section></>); }
