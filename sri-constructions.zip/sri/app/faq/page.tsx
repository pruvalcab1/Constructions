import { CTASection, FAQ, PageHero, Section } from "@/components/ui";
import { meta } from "@/lib/seo";
export const metadata = meta("Frequently Asked Questions", "Answers about the construction process, estimates, renovation and consultancy at Sri Constructions.", "/faq");
export default function F() { return (<><PageHero title="Frequently Asked Questions" crumbs={[["FAQ", "/faq"]]} /><Section><FAQ /></Section><CTASection /></>); }
