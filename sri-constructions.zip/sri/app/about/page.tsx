import { CTASection, PageHero, ProcessTimeline, Section, SectionHeading, Stats } from "@/components/ui";
import { meta } from "@/lib/seo";
export const metadata = meta("About Us", "Learn how Sri Constructions plans, builds and delivers residential, commercial and industrial projects.", "/about");
export default function About() {
  return (<><PageHero title="About Sri Constructions" text="A construction company focused on clear planning, careful workmanship and honest communication." crumbs={[["About", "/about"]]} />
    <Section><div className="grid gap-12 lg:grid-cols-2"><SectionHeading title="Who we are" /><div className="space-y-5 text-lg text-ink/75"><p>Sri Constructions builds homes, commercial buildings and industrial facilities, and supports owners with renovation, interiors and technical consultancy.</p><p>We keep scope, cost and schedule visible so decisions are made with full information. [ADD COMPANY HISTORY, FOUNDER NAME AND CERTIFICATIONS]</p></div></div></Section>
    <Stats /><Section className="bg-navy"><SectionHeading dark title="How we work" /><div className="mt-14"><ProcessTimeline /></div></Section><CTASection /></>);
}
