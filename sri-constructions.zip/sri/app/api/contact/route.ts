import { NextResponse } from "next/server";
const clean = (v: unknown, max: number) => String(v ?? "").replace(/[<>\u0000-\u001f]/g, " ").trim().slice(0, max);
export async function POST(req: Request) {
  let body: Record<string, unknown>;
  try { body = await req.json(); } catch { return NextResponse.json({ errors: { form: "Invalid request" } }, { status: 400 }); }
  if (body.company) return NextResponse.json({ ok: true }); // honeypot
  const d = { name: clean(body.name, 80), phone: clean(body.phone, 20), email: clean(body.email, 120), location: clean(body.location, 120), type: clean(body.type, 40), budget: clean(body.budget, 40), message: clean(body.message, 1500) };
  const errors: Record<string, string> = {};
  if (d.name.length < 2) errors.name = "Please enter your name.";
  if (!/^[+\d][\d\s()-]{6,18}$/.test(d.phone)) errors.phone = "Please enter a valid phone number.";
  if (d.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(d.email)) errors.email = "Please enter a valid email.";
  if (Object.keys(errors).length) return NextResponse.json({ errors }, { status: 422 });
  // TODO: deliver using CONTACT_TO_EMAIL / SMTP_URL (server env only) or push to your CRM/CMS.
  console.info("[contact] new enquiry", { name: d.name, type: d.type });
  return NextResponse.json({ ok: true });
}
