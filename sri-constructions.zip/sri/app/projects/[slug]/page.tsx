import { notFound } from "next/navigation";
import { Check } from "lucide-react";
import { CTASection, PageHero, Section, SectionHeading } from "@/components/ui";
import { projects } from "@/lib/site";
import { meta } from "@/lib/seo";
type P = { params: Promise<{ slug: string }> };
export const generateStaticParams = () => projects.map((p) => ({ slug: p.slug }));
export async function generateMetadata({ params }: P) { const { slug } = await params; const p = projects.find((x) => x.slug === slug); return p ? meta(p.name, p.short, `/projects/${p.slug}`) : {}; }
export default async function ProjectPage({ params }: P) {
  const { slug } = await params; const p = projects.find((x) => x.slug === slug); if (!p) notFound();
  return (<><PageHero title={p.name} text={p.short} crumbs={[["Projects", "/projects"], [p.name, `/projects/${p.slug}`]]} />
    <Section><dl className="grid grid-cols-2 gap-px bg-navy/10 lg:grid-cols-4">{[["Location", p.location], ["Type", p.category], ["Year", p.year], ["Scope", p.scope.join(", ")]].map(([k, v]) => <div key={k} className="bg-white p-6"><dt className="text-xs font-semibold uppercase tracking-widest text-gold">{k}</dt><dd className="mt-2 font-display text-lg text-navy">{v}</dd></div>)}</dl>
      <div className={`tone-${p.tone} grid-bg mt-10 aspect-[16/8] w-full`} role="img" aria-label={`${p.name} placeholder image`} />
      <div className="mt-16 grid gap-12 lg:grid-cols-3">{[["Overview", p.overview], ["Challenges", p.challenge], ["Solution", p.solution]].map(([t, x]) => <div key={t}><h2 className="font-display text-2xl text-navy">{t}</h2><p className="mt-3 text-ink/70">{x}</p></div>)}</div></Section>
    <Section className="bg-sand"><SectionHeading title="Construction gallery" text="Add project photographs here." /><div className="mt-10 grid gap-4 sm:grid-cols-3">{[0, 1, 2].map((i) => <div key={i} className={`tone-${(p.tone + i) % 4} grid-bg aspect-[4/3]`} role="img" aria-label="Gallery placeholder" />)}</div>
      <h2 className="mt-16 font-display text-2xl text-navy">Highlights</h2><ul className="mt-5 grid gap-3 sm:grid-cols-3">{p.highlights.map((h, i) => <li key={i} className="flex gap-3 bg-white p-4"><Check className="text-gold" aria-hidden />{h}</li>)}</ul></Section><CTASection /></>);
}
