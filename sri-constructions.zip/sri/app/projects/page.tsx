import Link from "next/link";
import { CTASection, PageHero, ProjectGrid, Section } from "@/components/ui";
import { projects } from "@/lib/site";
import { meta } from "@/lib/seo";
export const metadata = meta("Projects", "Selected residential, commercial, industrial and renovation projects by Sri Constructions.", "/projects");
const cats = ["All", "Residential", "Commercial", "Industrial", "Renovation"];
export default async function Projects({ searchParams }: { searchParams: Promise<{ category?: string }> }) {
  const c = (await searchParams).category ?? "All";
  const items = c === "All" ? projects : projects.filter((p) => p.category === c);
  return (<><PageHero title="Our Projects" crumbs={[["Projects", "/projects"]]} text="A selection of our work across building types." />
    <Section><nav aria-label="Project categories" className="mb-10 flex flex-wrap gap-3">{cats.map((k) => <Link key={k} href={k === "All" ? "/projects" : `/projects?category=${k}`} aria-current={k === c ? "page" : undefined} className={`px-5 py-2 text-sm font-semibold ${k === c ? "bg-navy text-white" : "bg-mist text-navy hover:bg-gold"}`}>{k}</Link>)}</nav>
      <ProjectGrid items={items} /></Section><CTASection /></>);
}
