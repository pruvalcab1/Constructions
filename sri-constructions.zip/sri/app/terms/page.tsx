import { PageHero, Section } from "@/components/ui";
import { meta } from "@/lib/seo";
export const metadata = meta("Terms & Conditions", "Terms & Conditions for the Sri Constructions website.", "/terms");
export default function Page() { return (<><PageHero title="Terms & Conditions" crumbs={[["Terms & Conditions", "/terms"]]} /><Section><div className="mx-auto max-w-2xl space-y-5 text-ink/75"><p>[ADD Terms & Conditions. Have this reviewed by a legal professional before launch.]</p><p>Enquiries submitted through this website are used only to respond to your request.</p></div></Section></>); }
