import type { Metadata, Viewport } from "next";
import Script from "next/script";
import "./globals.css";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { WhatsAppButton } from "@/components/WhatsAppButton";
import { JsonLd } from "@/components/ui";
import { site } from "@/lib/site";
import { orgSchema } from "@/lib/seo";
export const viewport: Viewport = { themeColor: "#0b1b2e", width: "device-width", initialScale: 1 };
export const metadata: Metadata = {
  metadataBase: new URL(site.url),
  title: { default: "Sri Constructions | Residential, Commercial & Industrial Construction", template: "%s | Sri Constructions" },
  description: "Sri Constructions plans and builds residential, commercial and industrial projects, with renovation, interiors and consultancy under one team.",
  alternates: { canonical: site.url }, robots: { index: true, follow: true },
};
const ga = process.env.NEXT_PUBLIC_GA_ID, px = process.env.NEXT_PUBLIC_META_PIXEL_ID;
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (<html lang="en"><body>
    <JsonLd data={orgSchema()} />
    <Header /><main id="main">{children}</main><Footer /><WhatsAppButton />
    {ga && <><Script src={`https://www.googletagmanager.com/gtag/js?id=${ga}`} strategy="afterInteractive" /><Script id="ga" strategy="afterInteractive">{`window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments)}gtag('js',new Date());gtag('config','${ga}');`}</Script></>}
    {px && <Script id="px" strategy="afterInteractive">{`!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,document,'script','https://connect.facebook.net/en_US/fbevents.js');fbq('init','${px}');fbq('track','PageView');`}</Script>}
  </body></html>);
}
