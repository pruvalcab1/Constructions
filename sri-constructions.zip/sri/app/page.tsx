import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { CTASection, FAQ, ProcessTimeline, ProjectGrid, Section, SectionHeading, ServiceGrid, Stats, Testimonials, WhyChooseUs } from "@/components/ui";
import { Reveal } from "@/components/Reveal";
import { meta } from "@/lib/seo";
export const metadata = meta("Sri Constructions | Residential, Commercial & Industrial Construction", "Sri Constructions plans and builds residential, commercial and industrial projects, with renovation, interiors and consultancy under one team.", "/");
const Skyline = () => <svg viewBox="0 0 1200 400" preserveAspectRatio="xMidYMax slice" className="absolute inset-x-0 bottom-0 h-3/5 w-full" aria-hidden><g fill="none" stroke="#d6a62f" strokeOpacity=".35" strokeWidth="1.5"><path d="M0 399h1200M80 399V240h110v159M110 240V200h50v40M260 399V120h120v279M300 120V80h40v40M300 160h40M300 200h40M300 240h40M450 399V220l90-70 90 70v179M700 399V160h150v239M730 160V110h90v50M900 399V260h130v139M1060 399V180h100v219"/></g></svg>;
export default function Home() {
  return (<>
    <section className="grid-bg relative flex min-h-[100svh] items-center overflow-hidden bg-navy px-5 pb-20 pt-32 lg:px-8">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_75%_20%,rgba(214,166,47,.22),transparent_55%)]" /><Skyline />
      <div className="relative mx-auto w-full max-w-7xl"><Reveal>
        <p className="mb-6 text-xs font-semibold uppercase tracking-[.35em] text-gold">Sri Constructions</p>
        <h1 className="h-display max-w-4xl text-5xl text-white sm:text-6xl lg:text-8xl">Building dreams.<br /><span className="text-gold">Creating legacies.</span></h1>
        <p className="mt-8 max-w-xl text-lg text-white/75 sm:text-xl">From thoughtful planning to flawless execution, Sri Constructions delivers spaces built for lasting value.</p>
        <div className="mt-10 flex flex-col gap-4 sm:flex-row"><Link href="/contact" className="btn btn-gold">Start Your Project <ArrowRight size={18} aria-hidden /></Link><Link href="/projects" className="btn btn-line">Explore Our Projects</Link></div>
        <p className="mt-12 text-sm uppercase tracking-[.25em] text-white/55">Quality &bull; Transparency &bull; Timely Delivery</p></Reveal></div>
    </section>
    <Stats />
    <Section><div className="grid items-center gap-12 lg:grid-cols-2">
      <div><SectionHeading eyebrow="About us" title={<>We don&rsquo;t just build structures. We build the future.</>} text="Sri Constructions brings together thoughtful planning, skilled execution and uncompromising quality to create spaces that are built to last." />
        <Reveal><Link href="/about" className="btn btn-dark mt-8">Discover Sri Constructions</Link></Reveal></div>
      <Reveal><div className="tone-0 grid-bg relative aspect-[4/5] overflow-hidden"><div className="absolute inset-6 border border-gold/50" /><p className="absolute bottom-8 left-8 right-8 font-display text-2xl text-white">Replace with a project photograph.</p></div></Reveal></div></Section>
    <Section className="bg-mist"><SectionHeading eyebrow="What we do" title="Services built around your project" /><div className="mt-14"><ServiceGrid /></div></Section>
    <Section className="bg-sand"><SectionHeading eyebrow="Why Sri Constructions" title={<>Built on quality. Driven by trust.</>} /><div className="mt-14"><WhyChooseUs /></div></Section>
    <Section className="bg-navy"><SectionHeading dark eyebrow="How we work" title="A clear path from idea to handover" /><div className="mt-14"><ProcessTimeline /></div></Section>
    <Section><div className="flex flex-wrap items-end justify-between gap-6"><SectionHeading eyebrow="Featured projects" title="Work that speaks for itself" /><Link href="/projects" className="btn btn-dark">All Projects</Link></div><div className="mt-14"><ProjectGrid /></div></Section>
    <section className="bg-navy-2 px-5 py-24 text-white lg:px-8"><div className="mx-auto grid max-w-7xl items-center gap-12 lg:grid-cols-2"><SectionHeading dark eyebrow="Quality promise" title={<>Built to last. Designed to matter.</>} />
      <Reveal><ul className="grid gap-4 sm:grid-cols-2">{["Structural quality", "Material quality", "Skilled workmanship", "Safety", "Attention to detail", "Long-term durability"].map((t) => <li key={t} className="border-l-2 border-gold bg-white/5 px-5 py-4 font-medium">{t}</li>)}</ul></Reveal></div></section>
    <Section className="bg-mist"><SectionHeading eyebrow="Testimonials" title="What clients say" text="Sample content. Replace with real client testimonials in lib/site.ts." /><div className="mt-14"><Testimonials /></div></Section>
    <Section><div className="grid gap-12 lg:grid-cols-[1fr_1.4fr]"><SectionHeading eyebrow="FAQ" title="Common questions" /><FAQ /></div></Section>
    <CTASection />
  </>);
}
