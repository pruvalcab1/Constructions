import { CTASection, PageHero, Section, WhyChooseUs } from "@/components/ui";
import { meta } from "@/lib/seo";
export const metadata = meta("Why Choose Us", "What sets Sri Constructions apart: quality control, transparent process and dependable delivery.", "/why-us");
export default function Why() { return (<><PageHero title="Built on quality. Driven by trust." crumbs={[["Why Us", "/why-us"]]} /><Section><WhyChooseUs /></Section><CTASection /></>); }
