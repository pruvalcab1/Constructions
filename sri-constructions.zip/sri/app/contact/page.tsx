import { MessageCircle } from "lucide-react";
import { ContactForm } from "@/components/ContactForm";
import { PageHero, Section, SectionHeading, contactLines } from "@/components/ui";
import { site } from "@/lib/site";
import { meta } from "@/lib/seo";
export const metadata = meta("Contact Us", "Request a free consultation with Sri Constructions for your residential, commercial or industrial project.", "/contact");
export default function Contact() {
  return (<><PageHero title="Contact Us" text="Tell us about your project and we will arrange a consultation." crumbs={[["Contact", "/contact"]]} />
    <Section><div className="grid gap-14 lg:grid-cols-[1fr_1.6fr]"><div><SectionHeading title="Sri Constructions" />
      <dl className="mt-8 space-y-5">{[...contactLines(), ["Website", site.url]].map(([k, v]) => <div key={k}><dt className="text-xs font-semibold uppercase tracking-widest text-gold">{k}</dt><dd className="mt-1 text-lg">{v}</dd></div>)}</dl>
      {site.whatsapp ? <a className="btn btn-gold mt-8" href={`https://wa.me/${site.whatsapp}`}><MessageCircle size={18} aria-hidden />Chat on WhatsApp</a> : <p className="mt-8 text-sm text-ink/55">Set NEXT_PUBLIC_WHATSAPP to enable the WhatsApp button.</p>}</div>
      <ContactForm /></div></Section></>);
}
