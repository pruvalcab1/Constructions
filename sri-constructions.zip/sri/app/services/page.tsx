import { CTASection, PageHero, Section, ServiceGrid } from "@/components/ui";
import { meta } from "@/lib/seo";
export const metadata = meta("Construction Services", "Residential, commercial and industrial construction, renovation, interior design and consultancy from Sri Constructions.", "/services");
export default function Services() {
  return (<><PageHero title="Our Services" text="Construction and supporting services under one accountable team." crumbs={[["Services", "/services"]]} /><Section><ServiceGrid /></Section><CTASection /></>);
}
