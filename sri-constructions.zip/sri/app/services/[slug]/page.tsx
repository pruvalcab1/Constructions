import { notFound } from "next/navigation";
import { Check } from "lucide-react";
import { CTASection, FAQ, JsonLd, PageHero, ProcessTimeline, Section, SectionHeading } from "@/components/ui";
import { services, site } from "@/lib/site";
import { meta } from "@/lib/seo";
type P = { params: Promise<{ slug: string }> };
export const generateStaticParams = () => services.map((s) => ({ slug: s.slug }));
export async function generateMetadata({ params }: P) { const { slug } = await params; const s = services.find((x) => x.slug === slug); return s ? meta(s.title, s.short, `/services/${s.slug}`) : {}; }
export default async function ServicePage({ params }: P) {
  const { slug } = await params; const s = services.find((x) => x.slug === slug); if (!s) notFound();
  return (<><JsonLd data={{ "@context": "https://schema.org", "@type": "Service", name: s.title, description: s.short, provider: { "@type": "Organization", name: site.name, url: site.url }, ...(site.serviceAreas.length ? { areaServed: site.serviceAreas } : {}) }} />
    <PageHero title={s.title} text={s.short} crumbs={[["Services", "/services"], [s.title, `/services/${s.slug}`]]} />
    <Section><div className="grid gap-12 lg:grid-cols-2"><SectionHeading title="Overview" text={s.intro} />
      <ul className="space-y-4">{s.includes.map((i) => <li key={i} className="flex gap-3 border-b border-navy/10 pb-4 text-lg"><Check className="mt-1 shrink-0 text-gold" aria-hidden />{i}</li>)}</ul></div></Section>
    <Section className="bg-navy"><SectionHeading dark title="Our process" /><div className="mt-14"><ProcessTimeline /></div></Section>
    <Section><SectionHeading title="Frequently asked questions" /><div className="mt-10"><FAQ withSchema={false} /></div></Section><CTASection /></>);
}
