import { notFound } from "next/navigation";
import { CTASection, JsonLd, PageHero, Section } from "@/components/ui";
import { posts, site } from "@/lib/site";
import { meta } from "@/lib/seo";
type P = { params: Promise<{ slug: string }> };
export const generateStaticParams = () => posts.map((p) => ({ slug: p.slug }));
export async function generateMetadata({ params }: P) { const { slug } = await params; const p = posts.find((x) => x.slug === slug); return p ? meta(p.title, p.excerpt, `/blog/${p.slug}`) : {}; }
export default async function Post({ params }: P) {
  const { slug } = await params; const p = posts.find((x) => x.slug === slug); if (!p) notFound();
  return (<><JsonLd data={{ "@context": "https://schema.org", "@type": "BlogPosting", headline: p.title, datePublished: p.date, author: { "@type": "Organization", name: site.name }, publisher: { "@type": "Organization", name: site.name } }} />
    <PageHero title={p.title} crumbs={[["Blog", "/blog"], [p.title, `/blog/${p.slug}`]]} /><Section><article className="mx-auto max-w-2xl space-y-6 text-lg leading-relaxed text-ink/80">{p.body.map((t, i) => <p key={i}>{t}</p>)}</article></Section><CTASection /></>);
}
