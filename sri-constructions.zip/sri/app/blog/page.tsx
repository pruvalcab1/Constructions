import Link from "next/link";
import { PageHero, Section } from "@/components/ui";
import { posts } from "@/lib/site";
import { meta } from "@/lib/seo";
export const metadata = meta("Blog", "Practical construction guidance on budgets, contractors and renovation from Sri Constructions.", "/blog");
export default function Blog() {
  return (<><PageHero title="Insights" text="Practical notes on building and renovating." crumbs={[["Blog", "/blog"]]} /><Section><div className="grid gap-8 md:grid-cols-3">{posts.map((p) => <article key={p.slug} className="border-t-2 border-gold pt-5"><time dateTime={p.date} className="text-sm text-ink/55">{new Date(p.date).toLocaleDateString("en-IN", { dateStyle: "long" })}</time><h2 className="mt-2 font-display text-2xl text-navy"><Link href={`/blog/${p.slug}`} className="hover:text-gold">{p.title}</Link></h2><p className="mt-3 text-ink/70">{p.excerpt}</p></article>)}</div></Section></>);
}
