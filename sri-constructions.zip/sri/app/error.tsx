"use client";
export default function Error({ reset }: { error: Error; reset: () => void }) { return (<section className="grid min-h-[70vh] place-items-center px-5 pt-24 text-center"><div><h1 className="h-display text-3xl text-navy">Something went wrong</h1><button onClick={reset} className="btn btn-dark mt-6">Try again</button></div></section>); }
