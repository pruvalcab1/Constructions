"use client";
import { useState } from "react";
import { CheckCircle2, AlertCircle } from "lucide-react";
const types = ["Residential", "Commercial", "Industrial", "Renovation", "Interior Design", "Consultancy"];
const budgets = ["Not sure yet", "Under 25 lakh", "25 to 50 lakh", "50 lakh to 1 crore", "Above 1 crore"];
const f = "w-full border border-navy/20 bg-white px-4 py-3 text-ink focus:border-gold";
export function ContactForm() {
  const [state, setState] = useState<"idle" | "sending" | "ok" | "error">("idle");
  const [errors, setErrors] = useState<Record<string, string>>({});
  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault(); setState("sending"); setErrors({});
    const data = Object.fromEntries(new FormData(e.currentTarget));
    try {
      const r = await fetch("/api/contact", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(data) });
      const j = await r.json();
      if (r.ok) { setState("ok"); return; }
      setErrors(j.errors ?? {}); setState("error");
    } catch { setState("error"); }
  }
  if (state === "ok") return <div role="status" className="border border-gold bg-sand p-10 text-center"><CheckCircle2 className="mx-auto text-gold" size={44} aria-hidden /><h3 className="mt-4 font-display text-2xl text-navy">Thank you</h3><p className="mt-2 text-ink/70">Your enquiry has been received. Our team will contact you shortly.</p></div>;
  const Err = ({ k }: { k: string }) => errors[k] ? <p id={`${k}-err`} className="mt-1 text-sm text-red-700">{errors[k]}</p> : null;
  const a = (k: string) => ({ "aria-invalid": !!errors[k], "aria-describedby": errors[k] ? `${k}-err` : undefined });
  return (<form onSubmit={onSubmit} noValidate className="grid gap-5 sm:grid-cols-2">
    <div><label htmlFor="name" className="mb-1 block text-sm font-medium">Name *</label><input id="name" name="name" required autoComplete="name" maxLength={80} className={f} {...a("name")} /><Err k="name" /></div>
    <div><label htmlFor="phone" className="mb-1 block text-sm font-medium">Phone *</label><input id="phone" name="phone" type="tel" required autoComplete="tel" maxLength={20} className={f} {...a("phone")} /><Err k="phone" /></div>
    <div><label htmlFor="email" className="mb-1 block text-sm font-medium">Email</label><input id="email" name="email" type="email" autoComplete="email" maxLength={120} className={f} {...a("email")} /><Err k="email" /></div>
    <div><label htmlFor="location" className="mb-1 block text-sm font-medium">Project location</label><input id="location" name="location" maxLength={120} className={f} /></div>
    <div><label htmlFor="type" className="mb-1 block text-sm font-medium">Project type</label><select id="type" name="type" className={f} defaultValue=""><option value="">Select</option>{types.map((t) => <option key={t}>{t}</option>)}</select></div>
    <div><label htmlFor="budget" className="mb-1 block text-sm font-medium">Budget</label><select id="budget" name="budget" className={f} defaultValue=""><option value="">Select</option>{budgets.map((t) => <option key={t}>{t}</option>)}</select></div>
    <div className="sm:col-span-2"><label htmlFor="message" className="mb-1 block text-sm font-medium">Message</label><textarea id="message" name="message" rows={5} maxLength={1500} className={f} /></div>
    <input name="company" tabIndex={-1} autoComplete="off" aria-hidden className="hidden" />
    {state === "error" && <p role="alert" className="flex items-center gap-2 text-red-700 sm:col-span-2"><AlertCircle size={18} aria-hidden />Please check the highlighted fields and try again.</p>}
    <button disabled={state === "sending"} className="btn btn-dark sm:col-span-2 disabled:opacity-60">{state === "sending" ? "Sending..." : "Request a Consultation"}</button>
  </form>);
}
