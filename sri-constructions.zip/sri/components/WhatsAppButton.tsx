import { MessageCircle } from "lucide-react";
import { site } from "@/lib/site";
export function WhatsAppButton() {
  if (!site.whatsapp) return null;
  return <a href={`https://wa.me/${site.whatsapp}?text=${encodeURIComponent("Hello Sri Constructions, I would like to discuss a project.")}`} target="_blank" rel="noopener noreferrer" aria-label="Chat on WhatsApp" className="fixed bottom-5 right-5 z-40 grid h-14 w-14 place-items-center rounded-full bg-[#25D366] text-white shadow-xl transition-transform hover:scale-105"><MessageCircle aria-hidden /></a>;
}
