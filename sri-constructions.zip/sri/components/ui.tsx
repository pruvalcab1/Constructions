import Link from "next/link";
import * as Icons from "lucide-react";
import type { ReactNode } from "react";
import { Reveal } from "./Reveal";
import { Counter } from "./Counter";
import { site, isPlaceholder, stats, statsArePlaceholders, services, projects, faqs, testimonials, steps, benefits, type Project } from "@/lib/site";
import { crumbSchema } from "@/lib/seo";

export const Icon = ({ name, ...p }: { name: string; size?: number; className?: string }) => {
  const C = (Icons as unknown as Record<string, Icons.LucideIcon>)[name] ?? Icons.Building2; return <C aria-hidden {...p} />;
};
export const JsonLd = ({ data }: { data: object }) => <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(data).replace(/</g, "\\u003c") }} />;

export function SectionHeading({ eyebrow, title, text, dark, center }: { eyebrow?: string; title: ReactNode; text?: string; dark?: boolean; center?: boolean }) {
  return (<Reveal className={`max-w-3xl ${center ? "mx-auto text-center" : ""}`}>
    {eyebrow && <p className="mb-4 text-xs font-semibold uppercase tracking-[.3em] text-gold">{eyebrow}</p>}
    <h2 className={`h-display text-3xl sm:text-4xl lg:text-5xl ${dark ? "text-white" : "text-navy"}`}>{title}</h2>
    {text && <p className={`mt-5 text-lg leading-relaxed ${dark ? "text-white/70" : "text-ink/70"}`}>{text}</p>}
  </Reveal>);
}
export const Section = ({ children, className = "", id }: { children: ReactNode; className?: string; id?: string }) =>
  <section id={id} className={`px-5 py-20 sm:py-28 lg:px-8 ${className}`}><div className="mx-auto max-w-7xl">{children}</div></section>;

export function PageHero({ title, text, crumbs }: { title: string; text?: string; crumbs: [string, string][] }) {
  const all: [string, string][] = [["Home", "/"], ...crumbs];
  return (<section className="grid-bg relative overflow-hidden bg-navy px-5 pb-16 pt-36 text-white lg:px-8 lg:pb-24 lg:pt-44">
    <JsonLd data={crumbSchema(all)} />
    <div className="mx-auto max-w-7xl">
      <nav aria-label="Breadcrumb" className="mb-6 text-sm text-white/60"><ol className="flex flex-wrap gap-2">
        {all.map(([n, h], i) => <li key={h} className="flex gap-2">{i > 0 && <span aria-hidden>/</span>}{i < all.length - 1 ? <Link href={h} className="hover:text-gold">{n}</Link> : <span aria-current="page" className="text-gold">{n}</span>}</li>)}
      </ol></nav>
      <h1 className="h-display max-w-4xl text-4xl sm:text-5xl lg:text-6xl">{title}</h1>
      {text && <p className="mt-6 max-w-2xl text-lg text-white/70">{text}</p>}
    </div></section>);
}

export function Stats() {
  return (<Section className="bg-sand"><div className="grid grid-cols-2 gap-px bg-navy/10 lg:grid-cols-4">
    {stats.map((s) => <div key={s.label} className="bg-sand p-6 text-center sm:p-10">
      <div className="h-display text-4xl text-navy sm:text-6xl"><Counter to={s.value} suffix={s.suffix} text={s.text} /></div>
      <p className="mt-3 text-sm font-medium uppercase tracking-widest text-ink/60">{s.label}</p></div>)}
  </div>{statsArePlaceholders && <p className="mt-4 text-center text-xs text-ink/50">Placeholder figures. Replace in lib/site.ts before launch.</p>}</Section>);
}

export function ServiceGrid() {
  return (<div className="grid gap-px bg-navy/10 sm:grid-cols-2 lg:grid-cols-3">
    {services.map((s, i) => <Reveal key={s.slug} delay={i * 60} className="bg-white"><Link href={`/services/${s.slug}`} className="group relative block h-full overflow-hidden p-8 transition-colors hover:bg-navy sm:p-10">
      <span className="absolute -right-6 -top-6 h-24 w-24 rounded-full bg-gold/10 transition-transform duration-500 group-hover:scale-[4]" aria-hidden />
      <Icon name={s.icon} size={36} className="relative text-gold" />
      <h3 className="relative mt-8 font-display text-2xl text-navy group-hover:text-white">{s.title}</h3>
      <p className="relative mt-3 text-ink/70 group-hover:text-white/70">{s.short}</p>
      <span className="relative mt-8 inline-flex items-center gap-2 text-sm font-semibold text-navy group-hover:text-gold">Learn More <Icons.ArrowUpRight size={16} className="transition-transform group-hover:translate-x-1 group-hover:-translate-y-1" /></span>
    </Link></Reveal>)}
  </div>);
}

export function WhyChooseUs({ dark }: { dark?: boolean }) {
  return (<div className="grid gap-10 sm:grid-cols-2 lg:grid-cols-3">
    {benefits.map(([ic, t, d], i) => <Reveal key={t} delay={i * 60}><div className={`border-t-2 border-gold pt-6 ${dark ? "text-white" : ""}`}>
      <Icon name={ic} size={32} className="text-gold" /><h3 className="mt-5 font-display text-xl">{t}</h3>
      <p className={`mt-2 ${dark ? "text-white/65" : "text-ink/70"}`}>{d}</p></div></Reveal>)}
  </div>);
}

export function ProcessTimeline() {
  return (<ol className="grid gap-px bg-white/10 sm:grid-cols-2 lg:grid-cols-3">
    {steps.map(([t, d], i) => <li key={t} className="bg-navy"><Reveal delay={i * 70} className="p-8 sm:p-10">
      <span className="font-display text-5xl text-gold/80">{String(i + 1).padStart(2, "0")}</span>
      <h3 className="mt-4 font-display text-xl text-white">{t}</h3><p className="mt-2 text-white/65">{d}</p></Reveal></li>)}
  </ol>);
}

export function ProjectCard({ p }: { p: Project }) {
  return (<Link href={`/projects/${p.slug}`} className="group block overflow-hidden bg-navy">
    <div className={`tone-${p.tone} grid-bg relative aspect-[4/3] overflow-hidden`}>
      <svg viewBox="0 0 400 300" className="absolute inset-0 h-full w-full transition-transform duration-700 group-hover:scale-110" aria-hidden><g fill="none" stroke="#d6a62f" strokeOpacity=".55" strokeWidth="1.5"><path d="M60 250V150l70-50 70 50v100M200 250V110l60-40 80 60v120M40 250h340M95 250v-50h40v50"/></g></svg>
      <span className="absolute left-4 top-4 bg-gold px-3 py-1 text-xs font-bold uppercase tracking-widest text-navy">{p.category}</span>
      <div className="absolute inset-0 bg-navy/0 transition-colors duration-500 group-hover:bg-navy/40" />
    </div>
    <div className="p-6 text-white"><h3 className="font-display text-xl">{p.name}</h3>
      <p className="mt-1 flex items-center gap-1 text-sm text-gold"><Icons.MapPin size={14} aria-hidden />{p.location}</p>
      <p className="mt-3 text-sm text-white/65">{p.short}</p>
      <span className="mt-5 inline-flex items-center gap-2 text-sm font-semibold group-hover:text-gold">View Project <Icons.ArrowRight size={16} aria-hidden /></span></div>
  </Link>);
}
export const ProjectGrid = ({ items = projects }: { items?: Project[] }) => items.length
  ? <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">{items.map((p) => <ProjectCard key={p.slug} p={p} />)}</div>
  : <p className="border border-dashed border-navy/30 p-10 text-center text-ink/60">No projects in this category yet. Check back soon.</p>;

export function Testimonials() {
  return (<div className="grid gap-6 lg:grid-cols-3">{testimonials.map((t, i) => <Reveal key={i} delay={i * 80}>
    <figure className="h-full border border-navy/10 bg-white p-8 shadow-sm"><Icons.Quote className="text-gold" size={32} aria-hidden />
      <blockquote className="mt-4 text-lg leading-relaxed text-ink/80">{t.quote}</blockquote>
      <figcaption className="mt-6 border-t border-navy/10 pt-4"><p className="font-semibold text-navy">{t.name}</p><p className="text-sm text-ink/60">{t.project}</p></figcaption></figure></Reveal>)}</div>);
}

export function FAQ({ withSchema = true }: { withSchema?: boolean }) {
  return (<div className="divide-y divide-navy/10 border-y border-navy/10">
    {withSchema && <JsonLd data={{ "@context": "https://schema.org", "@type": "FAQPage", mainEntity: faqs.filter(([, a]) => !a.startsWith("[ADD")).map(([q, a]) => ({ "@type": "Question", name: q, acceptedAnswer: { "@type": "Answer", text: a } })) }} />}
    {faqs.map(([q, a]) => <details key={q} className="group py-5"><summary className="flex items-center justify-between gap-4 text-lg font-semibold text-navy">{q}<Icons.ChevronDown className="chev shrink-0 text-gold transition-transform" aria-hidden /></summary>
      <p className="mt-3 max-w-3xl text-ink/70">{a}</p></details>)}
  </div>);
}

export function CTASection() {
  return (<section className="grid-bg bg-navy px-5 py-24 text-center text-white lg:px-8"><div className="mx-auto max-w-3xl">
    <Reveal><h2 className="h-display text-3xl sm:text-5xl">Ready to build your next space?</h2>
      <p className="mt-6 text-lg text-white/70">Let&rsquo;s turn your vision into a space built with purpose, quality and confidence.</p>
      <div className="mt-10 flex flex-col justify-center gap-4 sm:flex-row"><Link href="/contact" className="btn btn-gold">Get a Free Consultation</Link><Link href="/contact" className="btn btn-line">Contact Us</Link></div></Reveal></div></section>);
}

export const contactLines = () => [["Phone", site.phone], ["Email", site.email], ["Location", site.location]] as const;
export { isPlaceholder };
