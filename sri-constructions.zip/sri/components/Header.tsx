"use client";
import Image from "next/image";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { Menu, X } from "lucide-react";
import { nav, site } from "@/lib/site";
export function Header() {
  const path = usePathname();
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  useEffect(() => { const f = () => setScrolled(scrollY > 24); f(); addEventListener("scroll", f, { passive: true }); return () => removeEventListener("scroll", f); }, []);
  useEffect(() => { setOpen(false); }, [path]);
  useEffect(() => { document.body.style.overflow = open ? "hidden" : ""; const k = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false); addEventListener("keydown", k); return () => removeEventListener("keydown", k); }, [open]);
  const solid = scrolled || open;
  return (
    <header className={`fixed inset-x-0 top-0 z-50 transition-all duration-300 ${solid ? "bg-navy/90 backdrop-blur-md shadow-lg shadow-black/20" : "bg-transparent"}`}>
      <a href="#main" className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:bg-gold focus:px-4 focus:py-2 focus:text-navy">Skip to content</a>
      <div className="mx-auto flex h-20 max-w-7xl items-center justify-between px-5 lg:px-8">
        <Link href="/" aria-label={`${site.name} home`} className="flex items-center"><Image src="/logo.png" alt={site.name} width={864} height={900} priority className="h-14 w-auto" /></Link>
        <nav aria-label="Primary" className="hidden items-center gap-8 lg:flex">
          {nav.map(([l, h]) => <Link key={h} href={h} aria-current={path === h ? "page" : undefined} className={`text-sm font-medium tracking-wide transition-colors hover:text-gold ${path === h ? "text-gold" : "text-white/90"}`}>{l}</Link>)}
        </nav>
        <Link href="/contact" className="btn btn-gold hidden lg:inline-flex">Get a Free Consultation</Link>
        <button className="p-2 text-white lg:hidden" aria-expanded={open} aria-controls="mobile-menu" aria-label={open ? "Close menu" : "Open menu"} onClick={() => setOpen(!open)}>{open ? <X size={28} /> : <Menu size={28} />}</button>
      </div>
      {open && (
        <div id="mobile-menu" className="fixed inset-x-0 top-20 bottom-0 overflow-y-auto bg-navy px-5 pb-10 pt-6 lg:hidden">
          <nav aria-label="Mobile" className="flex flex-col">
            {nav.map(([l, h]) => <Link key={h} href={h} className="border-b border-white/10 py-4 font-display text-2xl text-white">{l}</Link>)}
          </nav>
          <Link href="/contact" className="btn btn-gold mt-8 w-full">Get a Free Consultation</Link>
        </div>
      )}
    </header>
  );
}
