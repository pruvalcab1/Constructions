import Image from "next/image";
import Link from "next/link";
import { MessageCircle } from "lucide-react";
import { nav, services, site } from "@/lib/site";
export function Footer() {
  return (<footer className="bg-navy text-white/70"><div className="mx-auto grid max-w-7xl gap-12 px-5 py-20 sm:grid-cols-2 lg:grid-cols-4 lg:px-8">
    <div><Image src="/logo.png" alt={site.name} width={864} height={900} className="h-24 w-auto" /><p className="mt-5 max-w-xs">{site.tagline}</p></div>
    <div><h2 className="mb-5 text-sm font-semibold uppercase tracking-widest text-gold">Quick Links</h2><ul className="space-y-3">{nav.filter(([l]) => l !== "Why Us").map(([l, h]) => <li key={h}><Link href={h} className="hover:text-gold">{l}</Link></li>)}</ul></div>
    <div><h2 className="mb-5 text-sm font-semibold uppercase tracking-widest text-gold">Services</h2><ul className="space-y-3">{services.map((s) => <li key={s.slug}><Link href={`/services/${s.slug}`} className="hover:text-gold">{s.title.replace("Construction Consultancy", "Consultancy")}</Link></li>)}</ul></div>
    <div><h2 className="mb-5 text-sm font-semibold uppercase tracking-widest text-gold">Contact</h2><ul className="space-y-3"><li>{site.phone}</li><li>{site.email}</li><li>{site.location}</li>
      {site.whatsapp && <li><a className="inline-flex items-center gap-2 hover:text-gold" href={`https://wa.me/${site.whatsapp}`}><MessageCircle size={16} aria-hidden />WhatsApp</a></li>}</ul>
      {site.social.length > 0 && <ul className="mt-6 flex gap-4">{site.social.map((s) => <li key={s.href}><a href={s.href} rel="noopener noreferrer" className="hover:text-gold">{s.label}</a></li>)}</ul>}</div>
  </div><div className="border-t border-white/10 px-5 py-6 text-sm lg:px-8"><div className="mx-auto flex max-w-7xl flex-col justify-between gap-3 sm:flex-row">
    <p>&copy; 2026 Sri Constructions. All Rights Reserved.</p>
    <p className="flex gap-6"><Link href="/privacy" className="hover:text-gold">Privacy Policy</Link><Link href="/terms" className="hover:text-gold">Terms &amp; Conditions</Link><Link href="/sitemap-page" className="hover:text-gold">Sitemap</Link></p></div></div></footer>);
}
