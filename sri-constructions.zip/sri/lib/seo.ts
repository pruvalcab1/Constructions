import type { Metadata } from "next";
import { site, isPlaceholder } from "./site";
export function meta(title: string, description: string, path = ""): Metadata {
  const url = site.url + path;
  return { title, description, alternates: { canonical: url },
    openGraph: { title, description, url, siteName: site.name, type: "website", locale: "en_IN", images: [{ url: "/logo.png" }] },
    twitter: { card: "summary_large_image", title, description, images: ["/logo.png"] } };
}
export const orgSchema = () => ({ "@context": "https://schema.org", "@graph": [
  { "@type": ["Organization", "GeneralContractor", "LocalBusiness"], "@id": site.url + "#org", name: site.name, url: site.url, logo: site.url + "/logo.png", image: site.url + "/logo.png", description: site.tagline,
    ...(isPlaceholder(site.phone) ? {} : { telephone: site.phone }), ...(isPlaceholder(site.email) ? {} : { email: site.email }),
    ...(site.serviceAreas.length ? { areaServed: site.serviceAreas } : {}) },
  { "@type": "WebSite", "@id": site.url + "#website", url: site.url, name: site.name, publisher: { "@id": site.url + "#org" } } ] });
export const crumbSchema = (items: [string, string][]) => ({ "@context": "https://schema.org", "@type": "BreadcrumbList",
  itemListElement: items.map(([name, path], i) => ({ "@type": "ListItem", position: i + 1, name, item: site.url + path })) });
