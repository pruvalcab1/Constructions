// ===== EDIT ME: central business configuration =====
const PH = (s: string) => `[ADD ${s}]`;
export const site = {
  name: "Sri Constructions",
  url: process.env.NEXT_PUBLIC_SITE_URL ?? "https://www.your-domain.com",
  tagline: "Building spaces with quality, integrity and purpose.",
  phone: PH("PHONE NUMBER"),
  email: PH("EMAIL"),
  location: PH("LOCATION"),
  whatsapp: process.env.NEXT_PUBLIC_WHATSAPP ?? "", // digits only, e.g. 919876543210
  // Local SEO: add confirmed cities here; they feed schema + areaServed.
  serviceAreas: [] as string[],
  social: [] as { label: string; href: string }[],
};
export const isPlaceholder = (v: string) => v.startsWith("[ADD");

export type Service = { slug: string; title: string; icon: string; short: string; intro: string; includes: string[] };
export const services: Service[] = [
  { slug: "residential-construction", title: "Residential Construction", icon: "Home", short: "Independent houses, villas and apartment blocks, built around how you live.", intro: "From a single family home to multi-unit residences, we manage structure, finishes and site coordination under one accountable team.", includes: ["Independent houses and villas", "Apartment and multi-unit buildings", "Structural and finishing works", "Handover with documentation"] },
  { slug: "commercial-construction", title: "Commercial Construction", icon: "Building2", short: "Offices, retail and mixed-use buildings delivered to a defined schedule.", intro: "Commercial spaces need predictable timelines and clean coordination between trades. We plan the sequence before the first excavation.", includes: ["Offices and showrooms", "Retail and mixed-use buildings", "Services coordination", "Phased delivery planning"] },
  { slug: "industrial-construction", title: "Industrial Construction", icon: "Factory", short: "Warehouses, factories and utility buildings engineered for function.", intro: "Industrial buildings are judged on loads, flow and safety. We build around your equipment, logistics and compliance needs.", includes: ["Factories and warehouses", "Heavy-duty flooring", "Steel and RCC structures", "Safety-led site management"] },
  { slug: "renovation", title: "Renovation", icon: "Hammer", short: "Structural repairs, remodelling and upgrades to existing buildings.", intro: "Renovation starts with understanding what is already there. We survey first, then scope work so surprises stay small.", includes: ["Structural assessment and repair", "Remodelling and extensions", "Waterproofing and facade works", "Occupied-building planning"] },
  { slug: "interior-design", title: "Interior Design", icon: "Armchair", short: "Layouts, materials and finishes coordinated with the build itself.", intro: "Designing interiors alongside construction avoids rework: services, joinery and lighting are planned together.", includes: ["Space planning", "Material and finish selection", "Custom joinery and lighting", "Site supervision of fit-out"] },
  { slug: "consultancy", title: "Construction Consultancy", icon: "ClipboardCheck", short: "Estimation, planning and project management for your own build.", intro: "If you already have a designer or contractor, we can act as your technical representative on cost, schedule and quality.", includes: ["Cost estimation and BOQ review", "Project scheduling", "Quality inspections", "Contractor coordination"] },
];

export type Project = { slug: string; name: string; location: string; category: "Residential" | "Commercial" | "Industrial" | "Renovation"; year: string; short: string; scope: string[]; overview: string; challenge: string; solution: string; highlights: string[]; tone: number };
// SAMPLE PROJECTS: replace with real work. Add an image path per project when photos are available.
export const projects: Project[] = [
  { slug: "sample-residence", name: "Sample Residence", location: PH("LOCATION"), category: "Residential", year: PH("YEAR"), short: "Placeholder entry for a completed family residence.", scope: ["Design coordination", "Structure", "Finishes"], overview: "Replace this text with a real overview of the project: client brief, built-up area and what made it distinctive.", challenge: "Describe a genuine site or design constraint here.", solution: "Describe how your team resolved it.", highlights: ["[ADD HIGHLIGHT]", "[ADD HIGHLIGHT]", "[ADD HIGHLIGHT]"], tone: 0 },
  { slug: "sample-office-building", name: "Sample Office Building", location: PH("LOCATION"), category: "Commercial", year: PH("YEAR"), short: "Placeholder entry for a commercial building.", scope: ["Structure", "Services coordination", "Fit-out"], overview: "Replace with real project details.", challenge: "Describe a genuine constraint.", solution: "Describe the approach.", highlights: ["[ADD HIGHLIGHT]", "[ADD HIGHLIGHT]", "[ADD HIGHLIGHT]"], tone: 1 },
  { slug: "sample-warehouse", name: "Sample Warehouse Facility", location: PH("LOCATION"), category: "Industrial", year: PH("YEAR"), short: "Placeholder entry for an industrial facility.", scope: ["Steel structure", "Flooring", "Utilities"], overview: "Replace with real project details.", challenge: "Describe a genuine constraint.", solution: "Describe the approach.", highlights: ["[ADD HIGHLIGHT]", "[ADD HIGHLIGHT]", "[ADD HIGHLIGHT]"], tone: 2 },
  { slug: "sample-home-renovation", name: "Sample Home Renovation", location: PH("LOCATION"), category: "Renovation", year: PH("YEAR"), short: "Placeholder entry for a renovation project.", scope: ["Assessment", "Remodelling", "Waterproofing"], overview: "Replace with real project details.", challenge: "Describe a genuine constraint.", solution: "Describe the approach.", highlights: ["[ADD HIGHLIGHT]", "[ADD HIGHLIGHT]", "[ADD HIGHLIGHT]"], tone: 3 },
];

export type Post = { slug: string; title: string; date: string; excerpt: string; body: string[] };
export const posts: Post[] = [
  { slug: "planning-a-house-construction-budget", title: "Planning a house construction budget", date: "2026-01-15", excerpt: "Where the money actually goes, and how to leave room for what you cannot yet see.", body: ["A construction budget is more than the quote for walls and slabs. Foundations, services, finishes, approvals and a contingency all compete for the same figure.", "Start with a clear scope and a priority list. Decide which finishes can be upgraded later and which structural choices cannot.", "Keep a contingency for site conditions and design changes. Reviewing the estimate against drawings before work begins is the cheapest way to avoid disputes."] },
  { slug: "questions-before-hiring-a-contractor", title: "Questions to ask before hiring a contractor", date: "2026-02-10", excerpt: "A short checklist covering scope, schedule, payments and site supervision.", body: ["Ask who will supervise the site day to day and how progress is reported.", "Ask how variations are priced and approved, and how payments are tied to completed stages.", "Ask to see completed work and speak with previous clients where possible."] },
  { slug: "renovation-vs-rebuild", title: "Renovation or rebuild: how to decide", date: "2026-03-05", excerpt: "Structure, layout and cost: the three things that decide the answer.", body: ["A structural survey is the starting point. Sound foundations and frames often make renovation viable.", "Compare the cost of fixing layout limits against starting fresh, including temporary accommodation and approvals.", "Where possible, get both options priced on the same scope before deciding."] },
];

export const faqs = [
  ["How does the construction process work?", "We move from consultation to planning and design, then estimation, construction, quality inspection and handover. You get a clear point of contact at each stage."],
  ["How do I start a project with Sri Constructions?", "Send an enquiry through the contact form or WhatsApp. We will arrange a consultation to understand your site, requirements and budget."],
  ["Do you handle design and planning?", "Yes. We coordinate architectural and structural design, or work with the designers you already have."],
  ["Do you undertake renovation projects?", "Yes, from structural repairs and waterproofing to remodelling and extensions."],
  ["Do you provide construction consultancy?", "Yes. We offer estimation, scheduling and quality inspection for owners who want independent technical support."],
  ["How do you estimate project costs?", "Estimates are built from drawings, specifications and a bill of quantities, so you can see what is included before work starts."],
  ["How do you maintain construction quality?", "Through stage-wise inspections, material checks against specification and supervision by experienced site staff."],
  ["What areas do you serve?", "[ADD SERVICE AREAS] Update the serviceAreas list in lib/site.ts once confirmed."],
] as const;

export const testimonials = [
  { quote: "Working with Sri Constructions was smooth from planning to execution. The team maintained excellent communication throughout the project.", name: "Client Name", project: "Residential Project" },
  { quote: "[ADD REAL TESTIMONIAL] Replace this sample with a quote from a real client.", name: "Client Name", project: "Commercial Project" },
  { quote: "[ADD REAL TESTIMONIAL] Replace this sample with a quote from a real client.", name: "Client Name", project: "Renovation Project" },
];
export const stats = [
  { value: 10, suffix: "+", label: "Years of Experience" },
  { value: 50, suffix: "+", label: "Projects Delivered" },
  { value: 100, suffix: "%", label: "Commitment to Quality" },
  { value: 0, suffix: "", label: "On-Time Project Delivery", text: "On-Time" },
];
export const statsArePlaceholders = true; // set false once real figures are entered
export const steps = [
  ["Consultation", "We listen to your requirements, site and budget."],
  ["Planning & Design", "Drawings, structure and specifications are finalised."],
  ["Estimation", "A detailed cost breakdown before work begins."],
  ["Construction", "Supervised execution with regular progress updates."],
  ["Quality Inspection", "Stage-wise checks and a final snag review."],
  ["Handover", "Documentation and walkthrough, then ongoing support."],
] as const;
export const benefits = [
  ["ShieldCheck", "Quality Construction", "Materials and workmanship checked against specification at every stage."],
  ["Eye", "Transparent Process", "Clear estimates, written scope and open reporting."],
  ["HardHat", "Skilled Professionals", "Experienced engineers, supervisors and trades."],
  ["Ruler", "Smart Planning", "Sequencing and procurement planned before work starts."],
  ["CalendarCheck", "Timely Delivery", "Schedules tracked against milestones, not hopes."],
  ["Handshake", "End-to-End Support", "From first consultation to handover and after."],
] as const;
export const nav = [["Home", "/"], ["About", "/about"], ["Services", "/services"], ["Projects", "/projects"], ["Why Us", "/why-us"], ["Blog", "/blog"], ["Contact", "/contact"]] as const;
